<!DOCTYPE html>
<html>
<body>

<?php
echo "My new PHP web site by greb  version 1!";
?>

</body>
</html>
