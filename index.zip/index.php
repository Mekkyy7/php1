<!DOCTYPE html>
<html>
<body>

<?php
echo "My new PHP web site by greb  version5555!";
?>

</body>
</html>
